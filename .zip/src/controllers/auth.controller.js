const User = require("../models/User");
const RefreshToken = require("../models/RefreshToken");
const ApiError = require("../utils/ApiError");
const env = require("../config/env");
const {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
  hashToken,
  newJti,
} = require("../utils/tokens");

const REFRESH_COOKIE_PATH = "/api/auth"; // the browser only sends the cookie to the auth routes

const cookieOptions = () => ({
  httpOnly: true, // JavaScript cannot read it (protects from XSS)
  secure: env.isProd || env.cookie.sameSite === "none",
  sameSite: env.cookie.sameSite,
  path: REFRESH_COOKIE_PATH,
});

const setRefreshCookie = (res, token) =>
  res.cookie(env.cookie.name, token, {
    ...cookieOptions(),
    maxAge: env.jwt.refreshDays * 24 * 60 * 60 * 1000,
  });

const clearRefreshCookie = (res) => res.clearCookie(env.cookie.name, cookieOptions());

// Creates a new login session: access token (JSON) + refresh token (httpOnly cookie, hash saved in DB)
const startSession = async (user, req, res, status = 200) => {
  const jti = newJti();
  const refreshToken = signRefreshToken(user, jti);
  const accessToken = signAccessToken(user);

  await RefreshToken.create({
    user: user._id,
    jti,
    tokenHash: hashToken(refreshToken),
    userAgent: req.get("user-agent"),
    ip: req.ip,
    expiresAt: new Date(Date.now() + env.jwt.refreshDays * 24 * 60 * 60 * 1000),
  });

  setRefreshCookie(res, refreshToken);
  res.status(status).json({ success: true, user, accessToken });
};

// POST /api/auth/signup
const signup = async (req, res) => {
  const { name, email, password } = req.body;

  if (await User.exists({ email })) throw new ApiError(409, "This email is already registered");

  const user = await User.create({ name, email, password });
  await startSession(user, req, res, 201);
};

// POST /api/auth/login
const login = async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email }).select("+password");
  // same message for unknown email and wrong password
  if (!user || !(await user.comparePassword(password))) {
    throw new ApiError(401, "Invalid email or password");
  }

  await startSession(user, req, res);
};

// POST /api/auth/refresh  - uses the refresh cookie, returns a new access token (+ rotates the refresh token)
const refresh = async (req, res) => {
  const token = req.cookies[env.cookie.name];
  if (!token) throw new ApiError(401, "No refresh token");

  let payload;
  try {
    payload = verifyRefreshToken(token);
  } catch {
    clearRefreshCookie(res);
    throw new ApiError(401, "Session expired, please log in again");
  }

  const stored = await RefreshToken.findOne({ jti: payload.jti });

  // Token is valid but not in the DB (or does not match) = it was already used -> possible theft.
  // Log the user out of every device.
  if (!stored || stored.tokenHash !== hashToken(token)) {
    await RefreshToken.deleteMany({ user: payload.sub });
    clearRefreshCookie(res);
    throw new ApiError(401, "Session expired, please log in again");
  }

  const user = await User.findById(payload.sub);
  if (!user) {
    await stored.deleteOne();
    clearRefreshCookie(res);
    throw new ApiError(401, "User no longer exists");
  }

  await stored.deleteOne(); // rotation: every refresh token can be used only once
  await startSession(user, req, res);
};

// POST /api/auth/logout  - ends this device's session
const logout = async (req, res) => {
  const token = req.cookies[env.cookie.name];
  if (token) {
    try {
      const { jti } = verifyRefreshToken(token);
      await RefreshToken.deleteOne({ jti });
    } catch {
      /* expired / invalid token - nothing to remove */
    }
  }
  clearRefreshCookie(res);
  res.json({ success: true, message: "Logged out" });
};

// POST /api/auth/logout-all  (protected) - ends every session of this user
const logoutAll = async (req, res) => {
  await RefreshToken.deleteMany({ user: req.user._id });
  clearRefreshCookie(res);
  res.json({ success: true, message: "Logged out from all devices" });
};

// GET /api/auth/me  (protected)
const me = (req, res) => {
  res.json({ success: true, user: req.user });
};

module.exports = { signup, login, refresh, logout, logoutAll, me };
